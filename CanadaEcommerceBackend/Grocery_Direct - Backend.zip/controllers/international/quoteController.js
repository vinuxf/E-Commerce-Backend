const quoteService = require('../../services/international/quoteService');

const nodemailer = require('nodemailer');
require('dotenv').config();
const ejs = require("ejs");
const path = require("path");

// create
const createQuoteRequest = async (req, res) => {
  try {
    const { name, company_name, phone_number, email, product, quantity } = req.body;
    if (!name || !email || !product || !quantity) {
      return res.status(400).json({ error: 'Required fields are missing.' });
    }

    const newQuote = await quoteService.addQuoteRequest(
      name,
      company_name,
      phone_number,
      email,
      product,
      quantity
    );
    res.status(201).json({ message: 'Quote request created successfully!', data: newQuote });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// fetch all 
const getAllQuoteRequests = async (req, res) => {
  try {
    const quoteRequests = await quoteService.getQuoteRequests();
    res.status(200).json({ data: quoteRequests });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};



// Function to send email
const sendQuotation = async (req, res) => {
  const { email, customerName, quotationId, quotedItems, totalAmount, validityPeriod, notes } = req.body;

  try {

    const transporter = nodemailer.createTransport({
      host: "grocerysdirect.com", 
      port: 465,
      secure: true, 
      auth: {
        user: process.env.EMAIL || "security@grocerysdirect.com", 
        pass: process.env.PASSWORD, 
      },
    });

  
    const emailTemplatePath = path.join(__dirname, "../../views/quotationTemplate.ejs");
    console.log("Template path:", emailTemplatePath);

    const emailHtml = await ejs.renderFile(emailTemplatePath, {
      quotationId,        
      customerName,       
      quotedItems,       
      totalAmount,       
      validityPeriod,    
      notes,            
    });

    // Create the email options
    const mailOptions = {
      from: process.env.EMAIL, 
      to: email,               
      subject: `Quotation #${quotationId}`, 
      html: emailHtml,         
    };

    // Send the email
    await transporter.sendMail(mailOptions);

  
    res.status(200).json({
      success: true,
      message: "Quotation sent successfully!",
    });
  } catch (err) {
    console.error("Error sending quotation email:", err);
    res.status(500).json({
      success: false,
      message: "Failed to send the quotation email.",
      error: err.message,
    });
  }
};


const updateQuotationStatus = async (req, res) => {
  const { id } = req.params;
  const { status } = req.body;

  try {
    // Check if status is provided in the request
    if (!status) {
      return res.status(400).json({ message: "Status is required" });
    }

    // Call the service function to update the status
    const result = await quoteService.updateStatus(id, status);

    // If no rows were affected, return a 404 not found response
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Quotation not found" });
    }

    // Respond with success
    res.status(200).json({ message: "Quotation status updated successfully" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};






module.exports = {
  createQuoteRequest,
  getAllQuoteRequests,
  sendQuotation,
  updateQuotationStatus  
};
